# Location de voitures — JEE 2026/2027

Build : `mvn package` -> `target/location-voitures.war` (Tomcat 9, JDK 17)

1. Importer `db/schema.sql` dans MySQL.
2. Adapter l'utilisateur/mot de passe dans `src/main/resources/hibernate.cfg.xml`.
3. Déployer le .war sur Tomcat 9, ouvrir `http://localhost:8080/location-voitures/`.

Architecture : `model` <- `dao` <- `metier` <- `web` (Struts 2) -> JSP (`WEB-INF/jsp`).
