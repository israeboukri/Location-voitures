-- =====================================================================
--  Projet JEE 2026/2027 — Agence de location de voitures
--  Schéma MySQL 8 (InnoDB, utf8mb4)
--  Déduit du diagramme de classes du domaine (04_classes_domaine)
-- =====================================================================
--  Conventions
--  - Une table par entité ; clé primaire technique `id` auto-incrémentée
--    (l'identifiant noté dans la note du diagramme 04).
--  - Héritage Utilisateur → Client / Agent / Administrateur :
--    stratégie JOINED (@Inheritance(strategy = InheritanceType.JOINED)).
--    La table fille partage la clé primaire de `utilisateur`.
--  - Composition Vehicule ◆ Maintenance : ON DELETE CASCADE.
--  - Many-to-many Reservation ↔ Equipement : table de jointure
--    `reservation_equipement`.
--  - Périodes semi-ouvertes [date_debut, date_fin[ : date_debut < date_fin.
--  - Montants en dirhams (MAD), DECIMAL pour éviter les erreurs d'arrondi.
--  - Les attributs dérivés du diagramme (/age, /nbJours, /joursRetard)
--    ne sont PAS stockés : ils sont calculés en Java.
--    Exception : la facture stocke ses montants (HT, TVA, TTC) car
--    c'est un document figé ; un changement de taux ne doit pas la modifier.
--  - Moteur InnoDB obligatoire : transactions et verrou
--    SELECT ... FOR UPDATE (findByIdPourMiseAJour).
-- =====================================================================

CREATE DATABASE IF NOT EXISTS location_voitures
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE location_voitures;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS modele_prediction;
DROP TABLE IF EXISTS facture;
DROP TABLE IF EXISTS location;
DROP TABLE IF EXISTS reservation_equipement;
DROP TABLE IF EXISTS reservation;
DROP TABLE IF EXISTS equipement;
DROP TABLE IF EXISTS maintenance;
DROP TABLE IF EXISTS vehicule;
DROP TABLE IF EXISTS categorie;
DROP TABLE IF EXISTS parametres;
DROP TABLE IF EXISTS administrateur;
DROP TABLE IF EXISTS agent;
DROP TABLE IF EXISTS client;
DROP TABLE IF EXISTS utilisateur;
SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------------------
--  Utilisateurs (classe abstraite + 3 sous-classes, stratégie JOINED)
-- ---------------------------------------------------------------------
CREATE TABLE utilisateur (
  id                  BIGINT        NOT NULL AUTO_INCREMENT,
  nom                 VARCHAR(80)   NOT NULL,
  prenom              VARCHAR(80)   NOT NULL,
  email               VARCHAR(150)  NOT NULL,
  mot_de_passe_hache  VARCHAR(100)  NOT NULL,   -- hash BCrypt (60 caractères)
  telephone           VARCHAR(20)   NULL,
  actif               BOOLEAN       NOT NULL DEFAULT TRUE,
  date_creation       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT pk_utilisateur PRIMARY KEY (id),
  CONSTRAINT uq_utilisateur_email UNIQUE (email)
) ENGINE = InnoDB;

CREATE TABLE client (
  id              BIGINT        NOT NULL,
  numero_permis   VARCHAR(30)   NOT NULL,
  date_permis     DATE          NOT NULL,
  date_naissance  DATE          NOT NULL,
  adresse         VARCHAR(255)  NULL,
  CONSTRAINT pk_client PRIMARY KEY (id),
  CONSTRAINT uq_client_permis UNIQUE (numero_permis),
  CONSTRAINT fk_client_utilisateur FOREIGN KEY (id)
    REFERENCES utilisateur (id) ON DELETE CASCADE
) ENGINE = InnoDB;

CREATE TABLE agent (
  id         BIGINT       NOT NULL,
  matricule  VARCHAR(20)  NOT NULL,
  CONSTRAINT pk_agent PRIMARY KEY (id),
  CONSTRAINT uq_agent_matricule UNIQUE (matricule),
  CONSTRAINT fk_agent_utilisateur FOREIGN KEY (id)
    REFERENCES utilisateur (id) ON DELETE CASCADE
) ENGINE = InnoDB;

CREATE TABLE administrateur (
  id  BIGINT  NOT NULL,
  CONSTRAINT pk_administrateur PRIMARY KEY (id),
  CONSTRAINT fk_administrateur_utilisateur FOREIGN KEY (id)
    REFERENCES utilisateur (id) ON DELETE CASCADE
) ENGINE = InnoDB;

-- ---------------------------------------------------------------------
--  Paramètres globaux (une seule ligne, modifiée par l'administrateur)
-- ---------------------------------------------------------------------
CREATE TABLE parametres (
  id                    BIGINT        NOT NULL AUTO_INCREMENT,
  taux_tva              DECIMAL(5,4)  NOT NULL,   -- 0.2000 = 20 %
  taux_penalite_retard  DECIMAL(5,4)  NOT NULL,   -- 0.5000 = +50 % du tarif par jour de retard
  delai_grace           INT           NOT NULL,   -- jours avant expiration d'une réservation non retirée
  max_reservations_en_cours INT       NOT NULL,   -- anti-abus : réservations EN_ATTENTE/CONFIRMEE max par client
  CONSTRAINT pk_parametres PRIMARY KEY (id),
  CONSTRAINT ck_parametres_tva      CHECK (taux_tva >= 0 AND taux_tva < 1),
  CONSTRAINT ck_parametres_penalite CHECK (taux_penalite_retard >= 0),
  CONSTRAINT ck_parametres_grace    CHECK (delai_grace >= 0),
  CONSTRAINT ck_parametres_max      CHECK (max_reservations_en_cours >= 1)
) ENGINE = InnoDB;

-- ---------------------------------------------------------------------
--  Flotte
-- ---------------------------------------------------------------------
CREATE TABLE categorie (
  id           BIGINT        NOT NULL AUTO_INCREMENT,
  libelle      VARCHAR(50)   NOT NULL,
  description  VARCHAR(255)  NULL,
  CONSTRAINT pk_categorie PRIMARY KEY (id),
  CONSTRAINT uq_categorie_libelle UNIQUE (libelle)
) ENGINE = InnoDB;

-- Categorie "1" -- "0..*" Vehicule  (one-to-many)
CREATE TABLE vehicule (
  id                BIGINT         NOT NULL AUTO_INCREMENT,
  categorie_id      BIGINT         NOT NULL,
  marque            VARCHAR(50)    NOT NULL,
  modele            VARCHAR(50)    NOT NULL,
  immatriculation   VARCHAR(20)    NOT NULL,
  carburant         ENUM('ESSENCE','DIESEL','HYBRIDE','ELECTRIQUE') NOT NULL,
  boite_vitesse     ENUM('MANUELLE','AUTOMATIQUE')                  NOT NULL,
  nb_places         TINYINT        NOT NULL,
  tarif_journalier  DECIMAL(10,2)  NOT NULL,
  kilometrage       INT            NOT NULL DEFAULT 0,
  photo             VARCHAR(255)   NULL,      -- chemin ou nom du fichier image
  statut            ENUM('DISPONIBLE','LOUE','EN_MAINTENANCE') NOT NULL DEFAULT 'DISPONIBLE',
  CONSTRAINT pk_vehicule PRIMARY KEY (id),
  CONSTRAINT uq_vehicule_immatriculation UNIQUE (immatriculation),
  CONSTRAINT fk_vehicule_categorie FOREIGN KEY (categorie_id)
    REFERENCES categorie (id),
  CONSTRAINT ck_vehicule_places CHECK (nb_places BETWEEN 1 AND 9),
  CONSTRAINT ck_vehicule_tarif  CHECK (tarif_journalier > 0),
  CONSTRAINT ck_vehicule_km     CHECK (kilometrage >= 0)
) ENGINE = InnoDB;

CREATE INDEX ix_vehicule_recherche ON vehicule (categorie_id, carburant, boite_vitesse, tarif_journalier);

-- Vehicule "1" ◆-- "0..*" Maintenance  (composition)
CREATE TABLE maintenance (
  id                BIGINT         NOT NULL AUTO_INCREMENT,
  vehicule_id       BIGINT         NOT NULL,
  date_debut        DATE           NOT NULL,
  date_fin          DATE           NULL,      -- NULL = maintenance en cours
  type_maintenance  ENUM('VIDANGE','PNEUS','FREINS','REVISION','CARROSSERIE','AUTRE') NOT NULL,
  cout              DECIMAL(10,2)  NOT NULL DEFAULT 0,
  kilometrage       INT            NOT NULL,
  description       VARCHAR(255)   NULL,
  CONSTRAINT pk_maintenance PRIMARY KEY (id),
  CONSTRAINT fk_maintenance_vehicule FOREIGN KEY (vehicule_id)
    REFERENCES vehicule (id) ON DELETE CASCADE,
  CONSTRAINT ck_maintenance_periode CHECK (date_fin IS NULL OR date_fin > date_debut),
  CONSTRAINT ck_maintenance_cout    CHECK (cout >= 0)
) ENGINE = InnoDB;

CREATE INDEX ix_maintenance_periode ON maintenance (vehicule_id, date_debut, date_fin);

CREATE TABLE equipement (
  id               BIGINT         NOT NULL AUTO_INCREMENT,
  libelle          VARCHAR(80)    NOT NULL,
  prix_journalier  DECIMAL(10,2)  NOT NULL,
  actif            BOOLEAN        NOT NULL DEFAULT TRUE,
  CONSTRAINT pk_equipement PRIMARY KEY (id),
  CONSTRAINT uq_equipement_libelle UNIQUE (libelle),
  CONSTRAINT ck_equipement_prix CHECK (prix_journalier >= 0)
) ENGINE = InnoDB;

-- ---------------------------------------------------------------------
--  Réservations
-- ---------------------------------------------------------------------
-- Client "1" -- "0..*" Reservation ; Reservation "0..*" -- "1" Vehicule
CREATE TABLE reservation (
  id             BIGINT    NOT NULL AUTO_INCREMENT,
  client_id      BIGINT    NOT NULL,
  vehicule_id    BIGINT    NOT NULL,
  date_creation  DATETIME  NOT NULL DEFAULT CURRENT_TIMESTAMP,
  date_debut     DATE      NOT NULL,
  date_fin       DATE      NOT NULL,          -- période [date_debut, date_fin[
  km_estime      INT       NOT NULL,          -- kilométrage déclaré par le client
  risque_non_honoree DOUBLE NULL,            -- probabilité (IA) que la réservation ne soit pas honorée
  statut         ENUM('EN_ATTENTE','CONFIRMEE','REFUSEE','CONVERTIE','ANNULEE','EXPIREE') NOT NULL DEFAULT 'EN_ATTENTE',
  agent_id       BIGINT    NULL,              -- agent qui a validé ou refusé (NULL tant qu'en attente)
  date_traitement DATETIME NULL,
  motif_refus    VARCHAR(255) NULL,
  CONSTRAINT pk_reservation PRIMARY KEY (id),
  CONSTRAINT fk_reservation_client FOREIGN KEY (client_id)
    REFERENCES client (id),
  CONSTRAINT fk_reservation_vehicule FOREIGN KEY (vehicule_id)
    REFERENCES vehicule (id),
  CONSTRAINT fk_reservation_agent FOREIGN KEY (agent_id)
    REFERENCES agent (id),
  CONSTRAINT ck_reservation_periode CHECK (date_debut < date_fin),
  CONSTRAINT ck_reservation_km      CHECK (km_estime > 0),
  CONSTRAINT ck_reservation_risque  CHECK (risque_non_honoree IS NULL OR risque_non_honoree BETWEEN 0 AND 1)
) ENGINE = InnoDB;

-- Sert la requête existeConflit() : véhicule + statut + chevauchement de dates
CREATE INDEX ix_reservation_conflit ON reservation (vehicule_id, statut, date_debut, date_fin);
CREATE INDEX ix_reservation_client  ON reservation (client_id, statut);   -- limite par client
CREATE INDEX ix_reservation_attente ON reservation (statut, date_creation); -- file d'attente des agents

-- Reservation "0..*" -- "0..*" Equipement  (many-to-many, @ManyToMany + @JoinTable)
CREATE TABLE reservation_equipement (
  reservation_id  BIGINT  NOT NULL,
  equipement_id   BIGINT  NOT NULL,
  CONSTRAINT pk_reservation_equipement PRIMARY KEY (reservation_id, equipement_id),
  CONSTRAINT fk_resequip_reservation FOREIGN KEY (reservation_id)
    REFERENCES reservation (id) ON DELETE CASCADE,
  CONSTRAINT fk_resequip_equipement FOREIGN KEY (equipement_id)
    REFERENCES equipement (id)
) ENGINE = InnoDB;

-- ---------------------------------------------------------------------
--  Locations et factures
-- ---------------------------------------------------------------------
-- Reservation "1" -- "0..1" Location ; Agent "1" -- "0..*" Location
CREATE TABLE location (
  id                     BIGINT    NOT NULL AUTO_INCREMENT,
  reservation_id         BIGINT    NOT NULL,
  agent_id               BIGINT    NOT NULL,
  date_depart            DATETIME  NOT NULL,
  km_depart              INT       NOT NULL,
  carburant_depart       TINYINT   NOT NULL,     -- niveau du réservoir en %
  date_retour_prevue     DATE      NOT NULL,
  date_retour_effective  DATETIME  NULL,         -- NULL tant que la location est en cours
  km_retour              INT       NULL,
  carburant_retour       TINYINT   NULL,
  risque_retard          DOUBLE    NULL,         -- probabilité (IA) de retour en retard, calculée au pick-up
  statut                 ENUM('EN_COURS','TERMINEE') NOT NULL DEFAULT 'EN_COURS',
  CONSTRAINT pk_location PRIMARY KEY (id),
  CONSTRAINT uq_location_reservation UNIQUE (reservation_id),   -- multiplicité 0..1
  CONSTRAINT fk_location_reservation FOREIGN KEY (reservation_id)
    REFERENCES reservation (id),
  CONSTRAINT fk_location_agent FOREIGN KEY (agent_id)
    REFERENCES agent (id),
  CONSTRAINT ck_location_carb_dep CHECK (carburant_depart BETWEEN 0 AND 100),
  CONSTRAINT ck_location_carb_ret CHECK (carburant_retour IS NULL OR carburant_retour BETWEEN 0 AND 100),
  CONSTRAINT ck_location_km       CHECK (km_retour IS NULL OR km_retour >= km_depart),
  CONSTRAINT ck_location_risque   CHECK (risque_retard IS NULL OR risque_retard BETWEEN 0 AND 1),
  CONSTRAINT ck_location_retour   CHECK (
    (statut = 'EN_COURS' AND date_retour_effective IS NULL)
    OR (statut = 'TERMINEE' AND date_retour_effective IS NOT NULL AND km_retour IS NOT NULL)
  )
) ENGINE = InnoDB;

CREATE INDEX ix_location_agent  ON location (agent_id);
CREATE INDEX ix_location_statut ON location (statut, date_retour_prevue);   -- locations en cours / en retard

-- Location "1" -- "0..1" Facture
CREATE TABLE facture (
  id                   BIGINT         NOT NULL AUTO_INCREMENT,
  location_id          BIGINT         NOT NULL,
  numero               VARCHAR(30)    NOT NULL,   -- ex. FAC-2026-000123
  date_emission        DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  nb_jours             INT            NOT NULL,
  montant_location     DECIMAL(12,2)  NOT NULL,
  montant_equipements  DECIMAL(12,2)  NOT NULL DEFAULT 0,
  jours_retard         INT            NOT NULL DEFAULT 0,
  penalites_retard     DECIMAL(12,2)  NOT NULL DEFAULT 0,
  taux_tva             DECIMAL(5,4)   NOT NULL,   -- taux copié au moment de l'émission
  montant_ht           DECIMAL(12,2)  NOT NULL,
  montant_tva          DECIMAL(12,2)  NOT NULL,
  montant_ttc          DECIMAL(12,2)  NOT NULL,
  CONSTRAINT pk_facture PRIMARY KEY (id),
  CONSTRAINT uq_facture_location UNIQUE (location_id),   -- multiplicité 0..1
  CONSTRAINT uq_facture_numero UNIQUE (numero),
  CONSTRAINT fk_facture_location FOREIGN KEY (location_id)
    REFERENCES location (id),
  CONSTRAINT ck_facture_jours    CHECK (nb_jours >= 1 AND jours_retard >= 0),
  CONSTRAINT ck_facture_montants CHECK (
    montant_location >= 0 AND montant_equipements >= 0 AND penalites_retard >= 0
    AND montant_ht >= 0 AND montant_tva >= 0 AND montant_ttc >= 0
  )
) ENGINE = InnoDB;

-- Tableau de bord : chiffre d'affaires par mois
CREATE INDEX ix_facture_date ON facture (date_emission);

-- ---------------------------------------------------------------------
--  Composant IA : historique des modèles entraînés
--  (FIABILITE = réservation non honorée ; RETARD = retour en retard)
-- ---------------------------------------------------------------------
-- Administrateur "1" -- "0..*" ModelePrediction
CREATE TABLE modele_prediction (
  id                 BIGINT        NOT NULL AUTO_INCREMENT,
  administrateur_id  BIGINT        NOT NULL,
  type_modele        ENUM('FIABILITE','RETARD') NOT NULL,   -- deux modèles IA
  algorithme         VARCHAR(50)   NOT NULL,   -- ex. RandomForest
  date_entrainement  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  chemin_fichier     VARCHAR(255)  NOT NULL,   -- modèle sérialisé (.ser)
  taille_train       INT           NOT NULL,
  taille_test        INT           NOT NULL,
  f1                 DOUBLE        NOT NULL,
  precision_score    DOUBLE        NOT NULL,   -- "precision" est un mot réservé MySQL
  rappel             DOUBLE        NOT NULL,
  f1_baseline        DOUBLE        NOT NULL,
  actif              BOOLEAN       NOT NULL DEFAULT FALSE,
  CONSTRAINT pk_modele_prediction PRIMARY KEY (id),
  CONSTRAINT fk_modele_administrateur FOREIGN KEY (administrateur_id)
    REFERENCES administrateur (id),
  CONSTRAINT ck_modele_tailles CHECK (taille_train > 0 AND taille_test > 0)
) ENGINE = InnoDB;

CREATE INDEX ix_modele_actif ON modele_prediction (type_modele, actif, date_entrainement);

-- =====================================================================
--  Données de référence minimales
--  (l'historique de 2 ans / 1 000 locations est dans le script de seeding)
-- =====================================================================

-- Paramètres : TVA 20 %, pénalité +50 % du tarif par jour de retard, délai de grâce 1 jour,
-- 2 réservations en cours maximum par client (anti-abus)
INSERT INTO parametres (taux_tva, taux_penalite_retard, delai_grace, max_reservations_en_cours)
VALUES (0.2000, 0.5000, 1, 2);

-- Administrateur par défaut — email : admin@agence.ma / mot de passe : admin123
-- Hash BCrypt (préfixe $2a$, compatible jBCrypt et Spring Security).
-- À CHANGER après la première connexion.
INSERT INTO utilisateur (nom, prenom, email, mot_de_passe_hache, telephone, actif)
VALUES ('Admin', 'Agence', 'admin@agence.ma',
        '$2a$10$Zh9yFb13lcyMrYxud44Gruf1MT6GX1HDAiaEiniBLGdBxZbnO8HP6',
        NULL, TRUE);
INSERT INTO administrateur (id) VALUES (LAST_INSERT_ID());

INSERT INTO categorie (libelle, description) VALUES
  ('Économique', 'Petites citadines, faible consommation'),
  ('Compacte',   'Polyvalentes, 5 places'),
  ('Berline',    'Confort pour longs trajets'),
  ('SUV',        'Grand coffre, usage familial'),
  ('Utilitaire', 'Transport de marchandises');

INSERT INTO equipement (libelle, prix_journalier, actif) VALUES
  ('GPS',                       30.00, TRUE),
  ('Siège enfant',              25.00, TRUE),
  ('Conducteur supplémentaire', 50.00, TRUE),
  ('Chaînes à neige',           20.00, TRUE);

-- =====================================================================
--  Requête de conflit (référence pour ReservationDaoImpl.existeConflit)
--  Version SQL de la requête HQL paramétrée ; :vid, :debut, :fin = paramètres.
--
--  SELECT COUNT(*) FROM reservation r
--  WHERE r.vehicule_id = :vid
--    AND r.statut IN ('EN_ATTENTE', 'CONFIRMEE', 'CONVERTIE')
--    AND r.date_debut < :fin AND r.date_fin > :debut;              -- chevauchement [début, fin[
--
--  Règle explicite pour les locations prolongées
--  (LocationDaoImpl.existeLocationEnRetard) : tant qu'une location en retard
--  n'est pas clôturée, aucune NOUVELLE réservation n'est acceptée sur le véhicule.
--
--  SELECT COUNT(*) FROM location l
--  JOIN reservation r ON r.id = l.reservation_id
--  WHERE r.vehicule_id = :vid
--    AND l.statut = 'EN_COURS'
--    AND l.date_retour_prevue < CURRENT_DATE;
-- =====================================================================
