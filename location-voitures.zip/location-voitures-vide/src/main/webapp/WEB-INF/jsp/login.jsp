<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion - Location de voitures</title>
</head>
<body>
    <h1>Location de voitures</h1>
    <p>Squelette MVC opérationnel (Struts 2 &rarr; LoginAction &rarr; login.jsp).</p>
</body>
</html>
