package ma.uir.awd.metier;

public class VehiculeMetierImpl implements IVehiculeMetier {
}
