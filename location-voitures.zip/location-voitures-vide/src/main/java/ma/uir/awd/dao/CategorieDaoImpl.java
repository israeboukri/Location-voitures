package ma.uir.awd.dao;

import ma.uir.awd.model.Categorie;

public class CategorieDaoImpl extends GenericDaoImpl<Categorie, Long> implements ICategorieDao {
}
