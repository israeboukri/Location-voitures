package ma.uir.awd.metier;

public class LocationMetierImpl implements ILocationMetier {
}
