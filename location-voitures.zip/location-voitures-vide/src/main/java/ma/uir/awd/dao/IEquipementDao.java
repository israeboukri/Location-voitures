package ma.uir.awd.dao;

import ma.uir.awd.model.Equipement;

public interface IEquipementDao extends IGenericDao<Equipement, Long> {
}
