package ma.uir.awd.dao;

import ma.uir.awd.model.Reservation;

public interface IReservationDao extends IGenericDao<Reservation, Long> {
}
