package ma.uir.awd.metier;

public class MetierException extends RuntimeException {
}
