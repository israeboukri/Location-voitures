package ma.uir.awd.dao;

import ma.uir.awd.model.Equipement;

public class EquipementDaoImpl extends GenericDaoImpl<Equipement, Long> implements IEquipementDao {
}
