package ma.uir.awd.metier;

public class ReservationMetierImpl implements IReservationMetier {
}
