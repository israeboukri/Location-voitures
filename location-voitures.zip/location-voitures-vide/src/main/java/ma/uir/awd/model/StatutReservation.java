package ma.uir.awd.model;

public enum StatutReservation {
}
