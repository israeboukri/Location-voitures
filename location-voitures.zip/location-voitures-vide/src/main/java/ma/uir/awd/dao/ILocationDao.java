package ma.uir.awd.dao;

import ma.uir.awd.model.Location;

public interface ILocationDao extends IGenericDao<Location, Long> {
}
