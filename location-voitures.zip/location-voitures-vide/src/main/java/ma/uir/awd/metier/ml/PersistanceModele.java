package ma.uir.awd.metier.ml;

public class PersistanceModele {
}
