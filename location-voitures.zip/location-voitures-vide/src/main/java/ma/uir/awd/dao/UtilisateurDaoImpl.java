package ma.uir.awd.dao;

import ma.uir.awd.model.Utilisateur;

public class UtilisateurDaoImpl extends GenericDaoImpl<Utilisateur, Long> implements IUtilisateurDao {
}
