package ma.uir.awd.metier;

public class FacturationMetierImpl implements IFacturationMetier {
}
