package ma.uir.awd.metier.ml;

public class FiabiliteMetierImpl extends ModeleIAAbstrait implements IFiabiliteMetier {
}
