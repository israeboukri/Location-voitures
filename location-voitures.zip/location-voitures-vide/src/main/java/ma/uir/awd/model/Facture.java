package ma.uir.awd.model;

public class Facture {
}
