package ma.uir.awd.web;

public class AuthInterceptor {
}
