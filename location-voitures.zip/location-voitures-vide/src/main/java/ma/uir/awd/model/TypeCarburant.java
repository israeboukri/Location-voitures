package ma.uir.awd.model;

public enum TypeCarburant {
}
