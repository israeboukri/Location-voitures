package ma.uir.awd.metier;

public class UtilisateurMetierImpl implements IUtilisateurMetier {
}
