package ma.uir.awd.metier.ml;

public interface IRisqueRetardMetier {
}
