package ma.uir.awd.model;

public class Agent extends Utilisateur {
}
