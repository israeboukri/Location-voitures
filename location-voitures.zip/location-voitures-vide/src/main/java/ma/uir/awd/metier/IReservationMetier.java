package ma.uir.awd.metier;

public interface IReservationMetier {
}
