package ma.uir.awd.model;

public class Administrateur extends Utilisateur {
}
