package ma.uir.awd.dao;

import ma.uir.awd.model.Vehicule;

public interface IVehiculeDao extends IGenericDao<Vehicule, Long> {
}
