package ma.uir.awd.dao;

import ma.uir.awd.model.Utilisateur;

public interface IUtilisateurDao extends IGenericDao<Utilisateur, Long> {
}
