package ma.uir.awd.metier;

public class AuthMetierImpl implements IAuthMetier {
}
