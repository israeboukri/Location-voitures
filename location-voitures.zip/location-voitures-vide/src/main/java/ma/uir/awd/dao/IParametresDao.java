package ma.uir.awd.dao;

import ma.uir.awd.model.Parametres;

public interface IParametresDao extends IGenericDao<Parametres, Long> {
}
