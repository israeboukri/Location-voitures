package ma.uir.awd.dao;

import ma.uir.awd.model.Facture;

public interface IFactureDao extends IGenericDao<Facture, Long> {
}
