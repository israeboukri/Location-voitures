package ma.uir.awd.dao;

import ma.uir.awd.model.ModelePrediction;

public interface IModelePredictionDao extends IGenericDao<ModelePrediction, Long> {
}
