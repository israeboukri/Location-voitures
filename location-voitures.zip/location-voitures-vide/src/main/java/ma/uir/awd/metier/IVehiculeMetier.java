package ma.uir.awd.metier;

public interface IVehiculeMetier {
}
