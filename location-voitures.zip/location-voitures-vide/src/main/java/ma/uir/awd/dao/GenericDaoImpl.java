package ma.uir.awd.dao;

public abstract class GenericDaoImpl<T, ID> implements IGenericDao<T, ID> {
}
