package ma.uir.awd.dao;

import ma.uir.awd.model.Maintenance;

public class MaintenanceDaoImpl extends GenericDaoImpl<Maintenance, Long> implements IMaintenanceDao {
}
