package ma.uir.awd.model;

public abstract class Utilisateur {
}
