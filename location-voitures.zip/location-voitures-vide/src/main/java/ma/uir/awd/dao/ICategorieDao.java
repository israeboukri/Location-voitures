package ma.uir.awd.dao;

import ma.uir.awd.model.Categorie;

public interface ICategorieDao extends IGenericDao<Categorie, Long> {
}
