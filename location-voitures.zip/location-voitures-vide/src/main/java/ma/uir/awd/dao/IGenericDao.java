package ma.uir.awd.dao;

public interface IGenericDao<T, ID> {
}
