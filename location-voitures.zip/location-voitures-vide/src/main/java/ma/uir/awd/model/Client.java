package ma.uir.awd.model;

public class Client extends Utilisateur {
}
