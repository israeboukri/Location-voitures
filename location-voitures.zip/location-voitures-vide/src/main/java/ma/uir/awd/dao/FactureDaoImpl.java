package ma.uir.awd.dao;

import ma.uir.awd.model.Facture;

public class FactureDaoImpl extends GenericDaoImpl<Facture, Long> implements IFactureDao {
}
