package ma.uir.awd.dao;

import ma.uir.awd.model.Vehicule;

public class VehiculeDaoImpl extends GenericDaoImpl<Vehicule, Long> implements IVehiculeDao {
}
