package ma.uir.awd.web;

import com.opensymphony.xwork2.ActionSupport;

public class ModeleAction extends ActionSupport {
}
