package ma.uir.awd.dao;

public class HibernateUtil {
}
