package ma.uir.awd.dao;

import ma.uir.awd.model.Maintenance;

public interface IMaintenanceDao extends IGenericDao<Maintenance, Long> {
}
