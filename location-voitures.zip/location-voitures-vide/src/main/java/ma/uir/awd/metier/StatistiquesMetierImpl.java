package ma.uir.awd.metier;

public class StatistiquesMetierImpl implements IStatistiquesMetier {
}
