package ma.uir.awd.model;

public enum StatutVehicule {
}
