package ma.uir.awd.metier.ml;

public class RisqueRetardMetierImpl extends ModeleIAAbstrait implements IRisqueRetardMetier {
}
