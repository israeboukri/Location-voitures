package ma.uir.awd.dao;

import ma.uir.awd.model.ModelePrediction;

public class ModelePredictionDaoImpl extends GenericDaoImpl<ModelePrediction, Long> implements IModelePredictionDao {
}
