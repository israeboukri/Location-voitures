package ma.uir.awd.dao;

import ma.uir.awd.model.Parametres;

public class ParametresDaoImpl extends GenericDaoImpl<Parametres, Long> implements IParametresDao {
}
