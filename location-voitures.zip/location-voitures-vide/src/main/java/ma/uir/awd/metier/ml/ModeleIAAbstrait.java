package ma.uir.awd.metier.ml;

public abstract class ModeleIAAbstrait {
}
