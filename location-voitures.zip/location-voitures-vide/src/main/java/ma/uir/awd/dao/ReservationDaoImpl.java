package ma.uir.awd.dao;

import ma.uir.awd.model.Reservation;

public class ReservationDaoImpl extends GenericDaoImpl<Reservation, Long> implements IReservationDao {
}
