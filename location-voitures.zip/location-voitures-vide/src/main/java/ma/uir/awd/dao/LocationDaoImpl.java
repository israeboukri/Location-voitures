package ma.uir.awd.dao;

import ma.uir.awd.model.Location;

public class LocationDaoImpl extends GenericDaoImpl<Location, Long> implements ILocationDao {
}
